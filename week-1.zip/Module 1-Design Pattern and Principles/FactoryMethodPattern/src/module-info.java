/**
 * 
 */
/**
 * 
 */
module FactoryMethodPatternExample {
}