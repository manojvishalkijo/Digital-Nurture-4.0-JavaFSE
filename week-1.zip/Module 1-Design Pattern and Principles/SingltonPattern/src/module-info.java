/**
 * 
 */
/**
 * 
 */
module SingletonPattern {
}